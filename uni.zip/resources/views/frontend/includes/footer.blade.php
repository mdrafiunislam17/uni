<footer id="wp-footer" class="clearfix">


    <div class="footer-main">
        <div data-elementor-type="wp-post" data-elementor-id="161" class="elementor elementor-161">
            <section class="elementor-section elementor-top-section elementor-element elementor-element-3617f2f elementor-section-boxed elementor-section-height-default elementor-section-height-default row-top" data-id="3617f2f" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c9d0faa column-style-top" data-id="c9d0faa" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section class="elementor-section elementor-inner-section elementor-element elementor-element-12f861d elementor-section-boxed elementor-section-height-default elementor-section-height-default row-top" data-id="12f861d" data-element_type="section">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3270b1d column-style-top" data-id="3270b1d" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-7bdf724 elementor-widget__width-auto elementor-widget elementor-widget-gva-logo" data-id="7bdf724" data-element_type="widget" data-widget_type="gva-logo.default">
                                                <div class="elementor-widget-container">
                                                    <div class="gva-element-gva-logo gva-element">
                                                        <div class="gsc-logo text-center">

                                                            <a class="site-branding-logo" href="https://fmeducation.co.uk" title="Home" rel="Home">
                                                                <img src="wp-content/uploads/2020/12/FM-Education-Hub-Logo-3.png" alt="Home" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-00887f3 column-style-top" data-id="00887f3" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-81d7269 elementor-widget__width-auto elementor-widget-tablet__width-inherit elementor-widget elementor-widget-heading" data-id="81d7269" data-element_type="widget" data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">We Work Harder For You To Make Things Right</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ad92171 column-style-top" data-id="ad92171" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-fd50480 elementor-widget__width-auto elementor-widget elementor-widget-html" data-id="fd50480" data-element_type="widget" data-widget_type="html.default">
                                                <div class="elementor-widget-container">
                                                    <a class="btn-white" href="apply-now/">
                                                        apply now
                                                    </a> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="elementor-section elementor-inner-section elementor-element elementor-element-d0ed8a0 elementor-section-boxed elementor-section-height-default elementor-section-height-default row-top" data-id="d0ed8a0" data-element_type="section">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-ca9930e column-style-top" data-id="ca9930e" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-babd61f elementor-widget elementor-widget-heading" data-id="babd61f" data-element_type="widget" data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">Contact</h2>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-3bd7167 elementor-position-left icon-box-left elementor-vertical-align-middle elementor-view-default elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="3bd7167" data-element_type="widget"
                                                 data-widget_type="icon-box.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-box-wrapper">

                                                        <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class=" flaticon-calling"></i>				</span>
                                                        </div>

                                                        <div class="elementor-icon-box-content">

                                                            <h3 class="elementor-icon-box-title">
                                                                    <span>
							Call Anytime						</span>
                                                            </h3>

                                                            <p class="elementor-icon-box-description">
                                                                <a class="text-white" href="tel:+447951072254">+447951072254</a> </p>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-bb5ed31 elementor-position-left icon-box-left elementor-vertical-align-middle elementor-view-default elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="bb5ed31" data-element_type="widget"
                                                 data-widget_type="icon-box.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-box-wrapper">

                                                        <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class=" flaticon-email"></i>				</span>
                                                        </div>

                                                        <div class="elementor-icon-box-content">

                                                            <h3 class="elementor-icon-box-title">
                                                                    <span>
							Send Email						</span>
                                                            </h3>

                                                            <p class="elementor-icon-box-description">
                                                                <a class="text-white" href="mailto:info@fmeducation.co.uk">
                                                                    info@fmeducation.co.uk
                                                                </a> </p>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-f6102c7 elementor-position-left icon-box-left elementor-vertical-align-middle elementor-view-default elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="f6102c7" data-element_type="widget"
                                                 data-widget_type="icon-box.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-box-wrapper">

                                                        <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class=" flaticon-address"></i>				</span>
                                                        </div>

                                                        <div class="elementor-icon-box-content">

                                                            <h3 class="elementor-icon-box-title">
                                                                    <span>
							Visit Office						</span>
                                                            </h3>

                                                            <p class="elementor-icon-box-description">
                                                                <a class="text-white" href="#"> Suite 01, The Clock House, 4th Floor
                                                                    Barking,
                                                                    IG11 8EQ</a>
                                                            </p>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c8d5907 column-style-top" data-id="c8d5907" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-2cca1547 elementor-widget elementor-widget-heading" data-id="2cca1547" data-element_type="widget" data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">Links</h2>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-2df68c38 elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="2df68c38" data-element_type="widget" data-widget_type="icon-list.default">
                                                <div class="elementor-widget-container">
                                                    <ul class="elementor-icon-list-items">
                                                        <li class="elementor-icon-list-item">
                                                            <a href="about/">

                                                                <span class="elementor-icon-list-text">About</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="apply-now/">

                                                                <span class="elementor-icon-list-text">Apply Now</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="our-team/">

                                                                <span class="elementor-icon-list-text">Our Team</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="faq/">

                                                                <span class="elementor-icon-list-text">FAQ</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="contact/">

                                                                <span class="elementor-icon-list-text">Contact</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c01e267 column-style-top" data-id="c01e267" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-6a1e333c elementor-widget elementor-widget-heading" data-id="6a1e333c" data-element_type="widget" data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">Courses</h2>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-168d12a elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="168d12a" data-element_type="widget" data-widget_type="icon-list.default">
                                                <div class="elementor-widget-container">
                                                    <ul class="elementor-icon-list-items">
                                                        <li class="elementor-icon-list-item">
                                                            <a href="sfe-funded-courses/">

                                                                <span class="elementor-icon-list-text">SFE Funded Courses</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="self-funded/">

                                                                <span class="elementor-icon-list-text">Self Funded Courses</span>
                                                            </a>
                                                        </li>
                                                        <li class="elementor-icon-list-item">
                                                            <a href="free-courses/">

                                                                <span class="elementor-icon-list-text">Free Courses</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-36d94a5 column-style-top" data-id="36d94a5" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-cce3a5a elementor-widget elementor-widget-gva-logo" data-id="cce3a5a" data-element_type="widget" data-widget_type="gva-logo.default">
                                                <div class="elementor-widget-container">
                                                    <div class="gva-element-gva-logo gva-element">
                                                        <div class="gsc-logo text-center">

                                                            <a class="site-branding-logo" href="https://fmeducation.co.uk" title="Home" rel="Home">
                                                                <img src="wp-content/uploads/2020/12/FM-Education-Hub-Logo-3.png" alt="Home" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-138d5f2 elementor-widget elementor-widget-heading" data-id="138d5f2" data-element_type="widget" data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <h2 class="elementor-heading-title elementor-size-default">FM Education Hub</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
            <section class="elementor-section elementor-top-section elementor-element elementor-element-6e68e3c elementor-section-boxed elementor-section-height-default elementor-section-height-default row-top" data-id="6e68e3c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-1c3386f column-style-top" data-id="1c3386f" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-2b2b6538 elementor-widget elementor-widget-text-editor" data-id="2b2b6538" data-element_type="widget" data-widget_type="text-editor.default">
                                <div class="elementor-widget-container">
                                    <div>© Copyright 2024 by FM Education Hub</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-f436470 column-style-top" data-id="f436470" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-7188ad95 e-grid-align-right e-grid-align-mobile-center elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="7188ad95" data-element_type="widget" data-widget_type="social-icons.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-social-icons-wrapper elementor-grid">
                                            <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-square elementor-animation-push elementor-repeater-item-c714fc0" href="https://www.facebook.com/fmeducationhub/" target="_blank">
						<span class="elementor-screen-only">Facebook-square</span>
                                            <i class="fab fa-facebook-square"></i> </a>
                                            </span>
                                        <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-push elementor-repeater-item-44659a4" href="https://www.instagram.com/fmeducationhub/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
                                            <i class="fab fa-instagram"></i> </a>
                                            </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>


    <div class="return-top default"><i class="far fa-arrow-alt-circle-up"></i></div>

</footer>
